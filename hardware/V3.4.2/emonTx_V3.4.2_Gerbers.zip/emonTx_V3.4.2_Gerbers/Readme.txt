emonTx V3.4.2 - April 2016

PCB to be 1.6mm thickness
Solder Resist: Blue
Finish: HASL

* DC Socket (CN1) holes are to be milled slots plated through
* No silkscreen should overlap pads
* Check Welsh Daragon logo on the rear is re-produced OK :-)


OpenEnergyMonitor.org 
glyn.hudson@openenergymonitor.org
01248672607
07769871550
